Exceptions
==========

APIs of ``tower_cli`` raise exceptions defined in ``tower_cli.exceptions`` module. Check raise list of resource
public method documentation for possible exceptions.

.. automodule:: tower_cli.exceptions
   :members:
