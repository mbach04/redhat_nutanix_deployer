|Build Status| |Coverage Status| |Version| |Downloads| |License|
|Supported Python Versions|

Welcome to tower-cli
====================

**tower-cli** is a command line tool for Ansible Tower. It allows Tower
commands to be easily run from the Unix command line. It can also be
used as a client library for other python apps, or as a reference for
others developing API interactions with Tower's REST API.

For more information, please refer to our official docs hosted at http://tower-cli.readthedocs.io.
